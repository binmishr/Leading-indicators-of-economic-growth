# ./output/

Holds SVGs and the like produced from the analysis stage (and some from grooming)